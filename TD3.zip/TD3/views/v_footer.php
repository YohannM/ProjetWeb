<?php
/*
 * DS PHP
 * Vue Pied de page - footer
 *
 * Copyright 2017, Eric Dufour
 * http://techfacile.fr
 *
 * Licensed under the MIT license:
 * http://www.opensource.org/licenses/MIT
 *
 */
?>
					<!-- fin de page -->
				</div>
			</section>
		<!-- Pied de page -->
		<div class="footer">
			<div class="container" >
				<div class = "row">
					<div class = "col-md-3 col-sm-6 col-xs-12">
						<h3><?= TITRE.' - '.AUTEUR?></h3>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>	
