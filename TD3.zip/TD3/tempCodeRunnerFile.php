<?php
PATH_CONTROLLERS.$page.'.php'