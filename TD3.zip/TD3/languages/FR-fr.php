<?php
//isoler ici dans des constantes les textes affichés sur le site
define('LOGO', 'Logo de la compagnie'); // Affiché si image non trouvée

define('MENU_ACCUEIL','Accueil');

define('TEXTE_PAGE_404','Oops, la page demandée n\'existe pas !');
define('MESSAGE_ERREUR',"Une erreur s'est produite");
define('CAT_NON_TROUVEE',"La catégorie sélectionnée est introuvable");
define('ID_NON_TROUVEE',"Identifiant de photo incorrecte dans l'URL");

define('TITRE', 'Mes Photos');
define('TITRE_PAGE_ACCUEIL_TOUS', 'Accueil');
define('ERREUR_QUERY', 'Problème d\'accès à la base de données. Contactez l\'administrateur');
define('TITRE_PAGE_PHOTO','Les détails sur cette photo');

define('PHOTO_SELECTIONNEES', 'photos sélectionnée(s)');
define('PHOTO_AFFICHAGE','Que souhaitez-vous afficher ? ');
define('TOUTES_CATEGORIES','Toutes les catégories');
define('DESCRIPTION','Description');
define('CATEGORIE','Catégorie');
define('FICHIER','Fichier');
define('TITRE_PAGE_CATEGORIE','Les photos de la catégorie ');
define('VALIDER','Valider');

define('FRANCAIS','Français');
define('ANGLAIS','Anglais');
define('CHINOIS', 'Chinois');
define('CHOIX_LANGUE','Traduire la page : ');