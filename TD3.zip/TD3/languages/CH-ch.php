<?php
//isoler ici dans des constantes les textes affichés sur le site
define('LOGO', '公司徽标'); // Affiché si image non trouvée

define('MENU_ACCUEIL','欢迎');

define('TEXTE_PAGE_404','糟糕，请求的页面不存在！');
define('MESSAGE_ERREUR',"发生了错误");
define('CAT_NON_TROUVEE',"找不到所选类别");
define('ID_NON_TROUVEE',"URL中的照片ID不正确");

define('TITRE', '我的照片');
define('TITRE_PAGE_ACCUEIL_TOUS', '欢迎');
define('ERREUR_QUERY', '访问数据库的问题。联系管理员');
define('TITRE_PAGE_PHOTO','这张照片的详细信息');

define('PHOTO_SELECTIONNEES', '精选照片');
define('PHOTO_AFFICHAGE','你想看什么？ ');
define('TOUTES_CATEGORIES','所有类别');
define('DESCRIPTION','描述');
define('CATEGORIE','类别');
define('FICHIER','文件');
define('TITRE_PAGE_CATEGORIE','该类别的照片 ');
define('VALIDER','验证');

define('FRANCAIS','法国');
define('ANGLAIS','英语');
define('CHINOIS', '中国');
define('CHOIX_LANGUE','翻译页面：');