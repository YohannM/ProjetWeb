<?php
//isoler ici dans des constantes les textes affichés sur le site
define('LOGO', 'Company logo'); // Affiché si image non trouvée

define('MENU_ACCUEIL','Home');

define('TEXTE_PAGE_404','Oops, the requested page does not exist!');
define('MESSAGE_ERREUR',"An error has occurred");
define('CAT_NON_TROUVEE',"The selected category was not found");
define('ID_NON_TROUVEE',"Incorrect photo ID in the URL");

define('TITRE', 'My pictures');
define('TITRE_PAGE_ACCUEIL_TOUS', 'Home');
define('ERREUR_QUERY', 'Problem of access to the database. Contact the administrator');
define('TITRE_PAGE_PHOTO','Details on this photo');

define('PHOTO_SELECTIONNEES', 'selected photos');
define('PHOTO_AFFICHAGE','What would you like to view? ');
define('TOUTES_CATEGORIES','All categories');
define('DESCRIPTION','Description');
define('CATEGORIE','Category');
define('FICHIER','File');
define('TITRE_PAGE_CATEGORIE','Photos of the category ');
define('VALIDER','Validate');

define('FRANCAIS','French');
define('ANGLAIS','English');
define('CHINOIS', 'Chinese');
define('CHOIX_LANGUE','Translate this page : ');